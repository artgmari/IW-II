const mult = function(a,b){
    return a*b
}

module.exports = mult