const sub = function(a,b){
    return a-b
}

module.exports = sub
