const somaF = require("./soma")
const divF = require("./div")
const subF = require("./sub")
const multF = require("./mult")


console.log("A soma é: " + somaF(2,4))
console.log("A divisão é: " + divF(3,2))
console.log("A subtração é: " + subF(2,2))
console.log("A multiplicação é: " + multF(2,2))

